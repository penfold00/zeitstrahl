
import Zeitstrahl from "./Zeitstrahl";
import rehwild from "../public/rehwild.json";
import kategorien from "../public/kategorien.json";

function App() {
  return (
    <div className="p-4">
      <Zeitstrahl daten={rehwild} kategorienfarben={kategorien} />
    </div>
  );
}

export default App;
