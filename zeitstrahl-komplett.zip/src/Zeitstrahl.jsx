
import React from "react";

const monate = [
  "Jan", "Feb", "Mär", "Apr", "Mai", "Jun",
  "Jul", "Aug", "Sep", "Okt", "Nov", "Dez"
];

function monatIndex(monat) {
  return monate.findIndex(m => monat.startsWith(m));
}

function parseZeit(zeit) {
  const parts = zeit.split(" - ");
  if (parts.length === 1) {
    if (zeit.match(/^\d{1,2}\.\s*\w+/)) {
      const [tag, monat] = zeit.split(".");
      return { start: monatIndex(monat.trim()) + parseFloat(tag) / 30, end: monatIndex(monat.trim()) + parseFloat(tag) / 30, punkt: true };
    }
    return { start: monatIndex(zeit), end: monatIndex(zeit) };
  } else {
    const start = parts[0].trim();
    const end = parts[1].trim();

    const parseTeil = (teil) => {
      if (teil.match(/^\d{1,2}\.\s*\w+/)) {
        const [tag, monat] = teil.split(".");
        return monatIndex(monat.trim()) + parseFloat(tag) / 30;
      }
      return monatIndex(teil);
    };

    return { start: parseTeil(start), end: parseTeil(end) };
  }
}

export default function Zeitstrahl({ daten, kategorienfarben }) {
  return (
    <div className="w-full overflow-x-auto">
      <div className="sticky top-0 bg-white z-10">
        <h1 className="text-xl font-bold p-4">{daten.tierart}</h1>
        <div className="flex border-b px-4">
          <div className="w-32 shrink-0"></div>
          {monate.map((monat) => (
            <div key={monat} className="w-24 text-center text-sm font-semibold border-l border-gray-200">
              {monat}
            </div>
          ))}
        </div>
      </div>

      {daten.kategorien.map((kat) => {
        const farben = kategorienfarben[kat.name] || {};
        return (
          <div key={kat.name} className="flex border-b relative">
            <div
              className="w-32 shrink-0 px-2 py-3 text-sm font-medium sticky left-0 z-10"
              style={{
                backgroundColor: farben.farbeHintergrund,
                color: farben.farbeText,
              }}
            >
              {kat.name}
            </div>

            <div className="flex-1 relative">
              <div className="absolute inset-0 flex">
                {monate.map((_, idx) => (
                  <div key={idx} className="w-24 border-l border-gray-200"></div>
                ))}
              </div>

              {kat.ereignisse.map((ev, i) => {
                const { start, end, punkt } = parseZeit(ev.zeit);
                const left = `${start * 6}rem`;
                const width = punkt ? "0.5rem" : `${(end - start + 1) * 6}rem`;

                return (
                  <div
                    key={i}
                    className="absolute top-2"
                    style={{ left, width }}
                    title={ev.tooltip}
                  >
                    <div
                      className="px-2 py-1 text-xs rounded shadow text-center"
                      style={{
                        backgroundColor: farben.farbeAkzent,
                        color: "white",
                      }}
                    >
                      {ev.text}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        );
      })}
    </div>
  );
}
